const endpoint = 'https://petstore.swagger.io/';

const petsotreObject = {
        "id": 0,
        "category": {
          "id": 0,
          "name": "string"
        }
    }
const addPet = petsotreObject => {
    CSSSkewY.request('POST', endpoint, petsotreObject)
}

describe('Agregar una mascota a la tienda de Petstore', () => {
  
    it('Add a new pet', () => {
      // Definir el objeto de la mascota
      const newPet = {
        id: 0, // ID indico 0 ya que la API me dara uno
        name: 'Fido',
        status: 'available' // Puede ser 'available', 'pending', or 'sold'
      };
  
      // Hacer una solicitud POST a la API de Petstore para agregar la mascota
      cy.request({
        method: 'POST',
        url: 'https://petstore.swagger.io/v2/pet',
        body: newPet,
        headers: {
          'Content-Type': 'application/json'
        }
      }).then((response) => {
        // Verificar que la respuesta sea 200 OK
        expect(response.status).to.eq(200);
        expect(response.body).to.deep.include(newPet); // Verificar que la mascota agregada coincide con lo que enviamos
      });
    });
})