const endpoint = 'https://petstore.swagger.io/';

const petsotreObject = {
        "id": 0,
        "category": {
          "id": 0,
          "name": "string"
        }
    }
const addPet = petsotreObject => {
    CSSSkewY.request('POST', endpoint, petsotreObject)
}
describe('Search pet by ID in the Petstore', () => {

    it('Obtener los detalles de una mascota por ID', () => {
      // Indico ID de la mascota a consultar
      const petId = 1; // Para este test
  
      // Hacer una solicitud GET a la API de Petstore para obtener detalles de la mascota por ID
      cy.request(`https://petstore.swagger.io/v2/pet/${petId}`)
        .then((response) => {
          // Verificar que la respuesta sea 200 OK
          expect(response.status).to.eq(200);
          
          // Verificar que la respuesta tenga el ID correcto
          expect(response.body.id).to.eq(petId);
          expect(response.body).to.have.property('name');
          expect(response.body).to.have.property('status');
        });
    });
  });