const endpoint = 'https://petstore.swagger.io/';

const petsotreObject = {
        "id": 0,
        "category": {
          "id": 0,
          "name": "string"
        }
    }
const addPet = petsotreObject => {
    CSSSkewY.request('POST', endpoint, petsotreObject)
}

describe('Consultar mascotas por el estado "sold" en la tienda de Petstore', () => {

    it('Obtener todas las mascotas con el estado "sold"', () => {
      // Hacer una solicitud GET a la API de Petstore para obtener mascotas con estado "sold"
      cy.request('https://petstore.swagger.io/v2/pet/findByStatus?status=sold')
        .then((response) => {
          // Verificar que la respuesta sea 200 OK
          expect(response.status).to.eq(200);
  
          // Verificar que cada mascota en la respuesta tiene el estado "sold"
          response.body.forEach((pet) => {
            expect(pet.status).to.eq('sold');
          });
        });
    });
});    