const endpoint = 'https://petstore.swagger.io/';

const petsotreObject = {
        "id": 0,
        "category": {
          "id": 0,
          "name": "string"
        }
    }
const addPet = petsotreObject => {
    CSSSkewY.request('POST', endpoint, petsotreObject)
}
describe('Update the petname in the Petstore', () => {

    it('Update the petname ad status of a pet to "sold"', () => {
      // ID de la mascota que actualizare
      const petId = 1; // ID para este test
  
      // Datos actualizados para la mascota
      const updatedPetData = {
        id: petId,
        name: 'Pikachu',
        status: 'sold'
      };
  
      // Hacer una solicitud PUT a la API de Petstore para actualizar la mascota
      cy.request({
        method: 'PUT',
        url: `https://petstore.swagger.io/v2/pet`,
        body: updatedPetData,
        headers: {
          'Content-Type': 'application/json'
        }
      }).then((response) => {
        // Verificar que la respuesta sea 200 OK
        expect(response.status).to.eq(200);
  
        // Hacer una solicitud GET para asegurarse de que la mascota se actualizó correctamente
        cy.request(`https://petstore.swagger.io/v2/pet/${petId}`)
          .then((getResponse) => {
            // Verificar que el nombre y el estado se hayan actualizado correctamente
            expect(getResponse.status).to.eq(200);
            expect(getResponse.body.name).to.eq(updatedPetData.name);
            expect(getResponse.body.status).to.eq(updatedPetData.status);
          });
      });
    });

  });